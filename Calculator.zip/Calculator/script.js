let display = document.getElementById('display');
let string = "";
let buttons = document.querySelectorAll('.button');
buttons.forEach(button => {
    button.addEventListener('click', (e) => {
        let val = e.target.innerText;

        if (val === "=") {
            try {
                string = eval(string);
            } catch (err) {
                string = "Error";
            }
        } else if (val === "C") {
            string = "";
        } else if (val === "M+" || val === "M-") {
            return;
        } else {
            string += val;
        }
        display.value = string;
    });
});
document.addEventListener('keydown', function (e) {
    if (
        (e.key >= '0' && e.key <= '9') ||
        ['+', '-', '*', '/', '.', '%'].includes(e.key)
    ) {
        string += e.key;
    } else if (e.key === 'Enter') {
        try {
            string = eval(string);
        } catch {
            string = "Error";
        }
    } else if (e.key === 'Backspace') {
        string = string.slice(0, -1);
    } else if (e.key === 'Escape') {
        string = "";
    }

    display.value = string;
});
